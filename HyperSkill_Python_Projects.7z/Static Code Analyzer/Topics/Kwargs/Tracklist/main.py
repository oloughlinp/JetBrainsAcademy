tracks = {"Woodkid": {"The Golden Age": "Run Boy Run",
                      "On the Other Side": "Samara"},
          "Cure": {"Disintegration": "Lovesong",
                   "Wish": "Friday I'm in love"}}

def tracklist(**artists):
    for artist, songs in artists.items():
        print(artist)
        for album, song in songs.items():
            print(f"ALBUM: {album} TRACK: {song}")


tracklist(**tracks)