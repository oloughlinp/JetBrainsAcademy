# call the function `special` here
special(ingredient, **dishes)
