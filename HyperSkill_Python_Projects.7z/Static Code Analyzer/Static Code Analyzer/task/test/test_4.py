print("hello")


print("bye")



print("check")
