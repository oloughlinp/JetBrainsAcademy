print('hello')
print('hello')  # TODO
print('hello')  # TODO # TODO
# todo
# TODO just do it
print('todo')
print('TODO TODO')
todo()
todo = 'todo'
