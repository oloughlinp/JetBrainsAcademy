# [S001] Too long;
#
# [S002] Indentation is not a multiple of four;
#
# [S003] Unnecessary semicolon after a statement (note that semicolons are acceptable in comments);
#
# [S004] Less than two spaces before inline comments;
#
# [S005] TODO found (in comments only and case-insensitive);
#
# [S006] More than two blank lines preceding a code line (applies to the first non-empty line).

global previous_blank_lines
previous_blank_lines = 0

class PEPError():
    error_code = "X000"
    error_message = "Error Message"
    error_line_num = 0

    def __init__(self, error_line_num, error_code, error_message) -> None:
        super().__init__()
        self.error_message = error_message
        self.error_code = error_code
        self.error_line_num = error_line_num

    def __str__(self) -> str:
        return f"Line {self.error_line_num}: {self.error_code} {self.error_message}"

# Line too long
def check_s001(line_num, line):
    if len(code) > 79:
        return PEPError(line_num, "S001", "Too Long")
    return None

# Indentation is not a multiple of 4
def check_s002(line_num, line):
    return PEPError(line_num, "S002", "Indentation is not a multiple of 4") if (line != '\n' and (len(line) - len(line.lstrip())) % 4) else None

# Unnecessary semicolon after a statement (note that semicolons are acceptable in comments)
def check_s003(line_num, line):
    command = line.split("#")[0]
    inquote = False
    for char in command:
        if char == "\"" or char == "\'":
            inquote = not inquote
        if char == ";" and not inquote:
            return PEPError(line_num, "S003", "Unnecessary semicolon after a statement")
    return None

# Less than two spaces before inline comments;
def check_s004(line_num, line):
    if line.find("#") == -1 or line.find("#") == 0:
        return None
    command = line.split("#")[0]
    if len(command) > 0 and len(command) - len(command.rstrip(" ")) < 2:
        return PEPError(line_num, "S004", "Less than two spaces before inline comments")
    return None

# [S005] TODO found (in comments only and case-insensitive);
def check_s005(line_num, line):
    if line.find("#") == -1:
        return None
    return PEPError(line_num, "S005", "TODO found") if line.lower().find("todo") > -1 else None


# [S006] More than two blank lines preceding a code line (applies to the first non-empty line).
def check_S006(line_num, line, prev_blanks= 0):
    if prev_blanks > 2 and line.strip() != "":
        global previous_blank_lines
        previous_blank_lines = 0
        return PEPError(line_num, "S006", "More than two blank lines preceding a code line")
    return None

def check_line_errors(line_num, line, previous_blanks = 0):
    error_check_list = {
        "S001": check_s001(line_num, line),
        "S002": check_s002(line_num, line),
        "S003": check_s003(line_num, line),
        "S004": check_s004(line_num, line),
        "S005": check_s005(line_num, line),
        "S006": check_S006(line_num, line, previous_blanks),
    }
    pep_errors = []
    for check, pep in error_check_list.items():
        if isinstance(pep, PEPError):
            pep_errors.append(pep)
    return pep_errors

file_name = input()
with open(file_name, 'r') as file:
    all_errors = []
    for line_num, code in enumerate(file, 1):
        line_errors = check_line_errors(line_num, code, previous_blank_lines)
        for error in line_errors:
            if isinstance(error, PEPError):
                all_errors.append(error)
        if code.strip() == "":
            previous_blank_lines += 1
    for error in all_errors:
        print(error)
