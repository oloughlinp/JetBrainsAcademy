from collections import deque

expression = input()
error = False
q = deque()

for letter in expression:
    if letter == "(":
        q.append("(")
    elif letter == ")":
        if len(q) == 0:
            error = True
        else:
            q.pop()
if len(q) != 0 and not error:
    error = True
    q.

if error:
    print("ERROR")
else:
    print("OK")