nums = [x for x in range(3,1000,3)]
print(nums)