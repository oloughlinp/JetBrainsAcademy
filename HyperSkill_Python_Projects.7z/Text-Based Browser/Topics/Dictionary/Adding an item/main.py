# please work with the variable fav_flowers
fav_flowers = {'Alex': 'field flowers', 'Kate': 'daffodil', 'Eva': 'artichoke flower', 'Daniel': 'tulip'}
fav_flowers["Alice"] = "orchid"
print(fav_flowers)