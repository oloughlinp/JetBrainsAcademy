# create the function
def create_full_name(name, last_name):
    return name + " " + last_name