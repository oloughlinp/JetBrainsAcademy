import requests

from bs4 import BeautifulSoup
index = input()
link = input()
r = requests.get(link)
soup = BeautifulSoup(r.content, 'html.parser')
h2 = soup.find_all("h2")
print((h2[int(index)]))