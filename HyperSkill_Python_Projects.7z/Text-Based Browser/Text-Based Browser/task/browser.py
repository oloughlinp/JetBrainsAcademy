import argparse
import os
from collections import deque
import requests
from bs4 import BeautifulSoup
from colorama import Style, Fore

# write your code here
def main(tabs_loc):
    print(f"Main Running with args: {tabs_loc}")
    if not check_dir_exists(tabs_loc):
        os.mkdir(tabs_loc)
    website = input("Enter a website: ").lower()
    history = deque()
    while website.lower() != "exit":
        if website.lower() == "back":
            if len(history) == 0:
                website = input("Enter next site: ").lower()
                continue
            website = history.pop()
            website = history.pop()
            print("WEBSITE FROM HISTORY POP: " + website)
        elif "." not in website:
            website = input("Incorrect URL").lower()
            continue
        url = website if "https://" in website else "https://" + website
        history.append(website)
        req = requests.get(url)
        soup = BeautifulSoup(req.content, 'html.parser')
        website = website[:-4]
        print(f"website is now {website}")
        filepath = f"./{tabs_loc}/{website}"
        with open(filepath, "w") as file:
            file.write(soup.get_text())
            for i in soup.find_all("a"):
                i.string = "".join([Fore.BLUE, i.get_text(), Fore.RESET])
            print(soup.get_text())
        website = input("Enter next site: ").lower()


def check_dir_exists(dir_location):
    return os.access(dir_location, os.F_OK)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="This program saves the files to a folder \
                                                 for the text browser")
    parser.add_argument("dir")
    tabs_location = parser.parse_args().dir
    main(tabs_location)
